package com.company;

public class Main {

    public static void main(String[] args) {
	Coche coche = new Coche();
    coche.sumaNumeros(3.4, 4.5);


    }
}
class Vehiculo {
    public void diHola(){
        System.out.println("holaa!");
    }
}
class Coche extends Vehiculo {
    public void diHola() {
        System.out.println("soy un coche");
    }

    public int sumaNumeros(int a, int b) {
        System.out.println("soy el sumanumeros de int");
        return a + b;
    }


    public float sumaNumeros(float a, float b) {
        System.out.println("soy el sumanumeros de float");
        return a + b * (float) 9.0;
    }

    public void  sumaNumeros(double a, double b) {
        System.out.println("soy el sumanumeros de double");
        System.out.println(" el resultado es:" + (a + b));
    }


}