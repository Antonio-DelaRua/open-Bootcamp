package com.company;

public class Main {

    public static void main(String[] args) {
	Vehiculo vehiculo = new Vehiculo();
    vehiculo.setSonido("BRRR");
    System.out.println(vehiculo.getSonido());
    }
}
class Vehiculo {
    int VelocidadMaxima;
    String matricula;
    String sonido;

    public  Vehiculo(){
        System.out.println("estoy en el constructor");
    }
    public String getSonido(){
        return this.sonido;
    }
    public void setSonido(String sonido) {
        this.sonido = sonido;
    }
}
class Coche extends Vehiculo {

}
