package com.company;

public class Main {

    public static void main(String[] args) {

        Ejercicio( 10,  46 , 40);
    }
        public static void Ejercicio(int a, int b, int c)  {
        int resultado;
        resultado = a + b + c ;

        System.out.println(resultado);



    }
}
