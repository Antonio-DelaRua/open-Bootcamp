package com.company;

public class Main {

    public static void main(String[] args) {
        Coche micoche= new Coche();
        micoche.agregarP();
        micoche.agregarP();
        micoche.agregarP();
        micoche.agregarP();
        micoche.mostrarP();

    }
}