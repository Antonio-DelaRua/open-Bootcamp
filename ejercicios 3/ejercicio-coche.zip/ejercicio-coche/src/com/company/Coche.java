package com.company;

public class Coche {
    int numeroP=0;

    Coche(){

    }
    public void agregarP(){
        numeroP++;
    }
    public void mostrarP() {
        System.out.println("La cantidad de puerta es:"+numeroP);
    }
}
