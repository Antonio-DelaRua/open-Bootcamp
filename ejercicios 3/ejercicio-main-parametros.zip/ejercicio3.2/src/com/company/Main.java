package com.company;

public class Main {

    public static void main(String[] args) {
	  int a = 10;
      int b = 30;
      int c = 20;
      Ejercicio(a, b, c);

      System.out.println(a + b + c);
    }
    public static void Ejercicio(int a, int b, int c){

    }
}
