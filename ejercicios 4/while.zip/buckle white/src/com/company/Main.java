package com.company;

public class Main {

    public static void main(String[] args) {
	int numero = 2;
    while (numero > 1){
        System.out.println(numero );
        numero = numero +1;
    }
    }
}
