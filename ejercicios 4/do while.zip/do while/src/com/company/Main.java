package com.company;

public class Main {

    public static void main(String[] args) {
	 int marcador = 10;

     do{
         System.out.println(marcador);
         marcador = marcador -1;
     } while (marcador > 1);
    }
}
