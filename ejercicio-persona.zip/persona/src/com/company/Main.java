package com.company;

public class Main {

    public static void main(String[] args) {
	     Persona persona = new Persona();
         Persona paco = new Persona();
         persona.setNombre("Nombre: Antonio");
         persona.setEdad("edad: 35");
         persona.setTelefono("telefono: 637647821");


         paco.setNombre("nombre: Paco");
         paco.setEdad("edad: 24");
         paco.setTelefono("telefono: 633736434");

         String edad = persona.getEdad();
         String nombre = persona.getNombre();
         String telefono = persona.getTelefono();


         System.out.println(nombre);
         System.out.println(edad);
         System.out.println(telefono);


         System.out.println(paco.getNombre());
         System.out.println(paco.getEdad());
         System.out.println(paco.getTelefono());
    }
}

class Persona {
    private String edad;

    public void setEdad(String edad){
        this.edad = edad;
    }

    public String getEdad(){
        return this.edad;

    }

    private String nombre;

    public void setNombre(String nombre){
         this.nombre = nombre;
    }

    public String getNombre(){
        return this.nombre;
    }


    private String telefono;

    public void setTelefono(String telefono){
        this.telefono = telefono;
    }

    public String getTelefono(){
        return this.telefono;
    }
}